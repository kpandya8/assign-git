package AuctionHouse;

import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.util.Iterator;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JRadioButton;

/**
 * The abstract product of the factor method. 
 */
public abstract class ProductMenu extends JDialog {

	Product theProduct;
	boolean bLogout = true;

	JRadioButton TradingRadioButton = new JRadioButton();
	JComboBox<Trading> TradingCombox = new JComboBox<>();
	JButton TradingViewButton = new JButton();
	JButton TradingAddButton = new JButton();
	JRadioButton OptionRadio = new JRadioButton();
	JLabel TradingContentLabel = new JLabel();
	JComboBox<String> OptionCombo = new JComboBox<>();
	JButton OptionViewButton = new JButton();
	JButton OptionAddButton = new JButton();
	JButton buttonChangeProduct = new JButton();
	JButton buttonLogout = new JButton();
	private Person person;

	public ProductMenu() {

		try {
			jbInit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		setModal(true);
		setSize(503, 294);
	}

	private void jbInit() throws Exception {
		buttonChangeProduct.setText("Change Product");
		buttonChangeProduct.setBounds(new Rectangle(101, 211, 73, 37));
		buttonChangeProduct.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonChangeProduct_actionPerformed(e);
			}
		});
		this.getContentPane().setLayout(null);
		this.setTitle("");
		buttonLogout.setText("Logout");
		buttonLogout.setBounds(new Rectangle(267, 215, 73, 37));
		buttonLogout.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonLogout_actionPerformed(e);
			}
		});
		this.getContentPane().add(buttonChangeProduct, null);
		this.getContentPane().add(buttonLogout, null);
	}

	abstract void showMenu(Product theProduct);

	/**
	 * To show the add buttons. 
	 */
	public abstract void showAddButton();

	/**
	 * To show the view buttons. 
	 */
	public abstract void showViewButton();

	/**
	 * To show the radio buttons. 
	 */
	public abstract void showRadioButton();

	/**
	 * To show the labels. 
	 */
	public abstract void showLabels();

	public abstract void showComboxes();

	void TradeAddButton_actionPerformed(ActionEvent e) {
		Demo.theFacade.addTrade(theProduct);
		refresh();
	}

	void TradeViewButton_actionPerformed(ActionEvent e) {
		Trading theTrade = (Trading) TradingCombox.getSelectedItem();
		Demo.theFacade.viewTrade(theTrade);
	}

	void refresh() {
		TradingCombox.removeAllItems();
		Iterator<Trading> Iter = theProduct.TradingList.iterator();
		while (Iter.hasNext()) {
			TradingCombox.addItem(Iter.next());
		}
	}
	void buttonChangeProduct_actionPerformed(ActionEvent e) {
		bLogout = false;
		setVisible(false);
	}

	void buttonLogout_actionPerformed(ActionEvent e) {
		bLogout = true;
		setVisible(false);
	}
	boolean ifLogout() {
		return bLogout;
	}
}
