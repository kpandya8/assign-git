package AuctionHouse;


import java.text.DateFormat;
import java.util.Date;

public class Trading {

	protected String tradingName;
	protected String strTradingFilename;
	protected Date dueDate = new Date();
	protected String TradingSpec;
	protected OfferingList theOfferingList = new OfferingList();
	protected Offering suggestedOffering = new Offering();

	public Trading() {
	}
	public void setDueDate(Date theDueDate) {
		this.dueDate = theDueDate;
	}
	public void setTradingSpec(String theSpec) {
		this.TradingSpec = theSpec;
	}

	public boolean isOverDue() {
		Date today;
		today = new Date();
		return today.after(this.dueDate);
	}

	public Offering addOffering() {
		Offering myOffering = new Offering();
		return myOffering;
	}
	public void addOffering(Offering theOffering) {
		theOfferingList.add(theOffering);
	}

	public void getSolutionList() {
	}

	public Offering getOffering(String buyername) {
		OfferingIterator Iterator = new OfferingIterator(theOfferingList);
		return (Offering) Iterator.next(buyername);
	}

	public Offering getSuggestedOffering() {
		return suggestedOffering;
	}

	public OfferingIterator getOfferingIterator() {
		OfferingIterator theOfferingIterator = new OfferingIterator(theOfferingList);
		return theOfferingIterator;
	}

	public String toString() {
		return tradingName;
	}

	public String getDueDateString() {
		DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.SHORT);
		return dateFormat.format(dueDate);
	}

	public void accept(NodeVisitor visitor) {
		visitor.visitTrading(this);
	}

}
