package AuctionHouse;

import java.awt.Rectangle;
import java.awt.event.ActionEvent;
/**
 * A subclass of ProductMenu. One of the concrete products of the factor 
 * method. 
 */
public class ProduceProductMenu extends ProductMenu {

	public ProduceProductMenu() {
	}

	public void showMenu(Product theProduct) {
		setVisible(true);
	}

	/**
	 * To show the add buttons.
	 */
	public void showAddButton() {
		TradingAddButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TradeAddButton_actionPerformed(e);
			}
		});
		TradingAddButton.setText("Add");
		TradingAddButton.setBounds(new Rectangle(390, 54, 79, 29));
		OptionAddButton.setText("Add");
		OptionAddButton.setBounds(new Rectangle(390, 125, 79, 29));
		this.getContentPane().add(TradingAddButton, null);
		this.getContentPane().add(OptionAddButton, null);

	}

	/**
	 * To show the radio buttons. 
	 */
	public void showRadioButton() {
		TradingRadioButton.setText("Trading");
		TradingRadioButton.setBounds(new Rectangle(21, 55, 103, 26));
		this.getContentPane().add(TradingRadioButton, null);
		OptionRadio.setText("Produce Product Menu");
		OptionRadio.setBounds(new Rectangle(21, 128, 103, 26));
		this.getContentPane().add(OptionRadio, null);
	}

	/**
	 * To show the labels. 
	 */
	public void showLabels() {
		TradingContentLabel.setText("Trading Content");
		TradingContentLabel.setBounds(new Rectangle(23, 186, 432, 99));
		this.getContentPane().add(TradingContentLabel, null);

	}

	/**
	 * To show the view buttons. 
	 */
	public void showViewButton() {
		TradingViewButton.setText("View Produce Product");
		TradingViewButton.setBounds(new Rectangle(290, 54, 79, 29));
		TradingViewButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TradeViewButton_actionPerformed(e);
			}
		});
		OptionViewButton.setText("View Produce Product");
		OptionViewButton.setBounds(new Rectangle(290, 124, 79, 29));
		this.getContentPane().add(TradingViewButton, null);
		this.getContentPane().add(OptionViewButton, null);
	}

	public void showComboxes() {
		TradingCombox.setBounds(new Rectangle(140, 57, 126, 22));
		OptionCombo.setBounds(new Rectangle(140, 127, 126, 22));
		this.getContentPane().add(TradingCombox, null);
		this.getContentPane().add(OptionCombo, null);
		refresh();
	}

}
