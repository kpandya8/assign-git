package AuctionHouse;

import java.util.ArrayList;
/**
 * Subclass of ArrayList. One concreted List class that needs to be iterated.
 */
public class OfferingList extends ArrayList<Offering> {

	public OfferingList() {
	}


}
