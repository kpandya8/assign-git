package AuctionHouse;

import javax.swing.JDialog;
public class OfferingMenu extends JDialog {
    public OfferingMenu() {
    }

    void showMenu(Offering theOffering) {
        setVisible(true);
    }

}
