package AuctionHouse;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
/**
 * The abstract class of the list to be iterated 
 */
public class ClassProductList extends ArrayList<Product> {
	public ClassProductList() {
	}
 ProductIterator productIterator;
//
 ReminderVisitor reminderVisitor;
 
//
	public void accept(NodeVisitor visitor) {

	}

	void InitializeFromFile(String productListFile) {
		Scanner scanner;
		try {
			String strProductName = null;
			File file = new File(productListFile);
			scanner = new Scanner(file);
			while (scanner.hasNextLine()) {
				strProductName = scanner.nextLine();
				Product theProduct;
				theProduct = new Product(strProductName, 0);
				add(theProduct);
			}
			scanner.close();
		} catch (Exception ee) {
			//
		}
	}

	Product FindProductByProductName(String ProductName) {
		int nProductCount = size();
		for (int i = 0; i < nProductCount; i++) {
			Product theProduct;
			theProduct = (Product) get(i);
			if (theProduct.ProductName.compareTo(ProductName) == 0)
				return theProduct;
		}
		return null;
	}
}
