package AuctionHouse;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * The abstract iterator class in this class declares some iterating functions 
 * that need to be implemented in the concrete iterator classes. 
 */
public class ListIterator implements Iterator<Object>{
	ArrayList<Object> theList;
	/**
	 * If in the iterator there exists the "next", return true; else return false. 
	 */
	int CurrentNumber = -1;


	public ListIterator(ArrayList<Object> list) {
		theList = list;
	}

	public boolean hasNext(){
		if (CurrentNumber >= theList.size() - 1)
			return false;
		else
			return true;
	}

	/**
	 * If hasNext, return the next Item, move the current Item to the next item. Else return null.
	 */
	public Object next(){
		if (hasNext()) {
			CurrentNumber++;
			return theList.get(CurrentNumber);
		} else {
			return null;
		}
	}

	/**
	 * Remove the current item from the list.
	 */
	public void remove(){
		theList.remove(CurrentNumber);
	}

}
